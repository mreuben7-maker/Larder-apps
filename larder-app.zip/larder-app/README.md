# Larder — App Store submission package

**Larder: Cook What You Have** — the fridge-photo recipe app, now packaged for the App Store as a free native app monetized through affiliate links.

This folder has three parts:

```
larder-app/
├── backend/          → Express server (photo → ingredient list). Deploy this separately, publicly.
├── mobile-app/        → Capacitor project that wraps the web app as a real iOS/Android app.
└── store-assets/       → Icon, App Store listing copy, privacy policy.
```

Everything here is real, working code — the parts you genuinely cannot do without me are: owning a Mac with Xcode, an Apple Developer account, and your own API keys. I've done everything else.

---

## Step 1 — Deploy the backend (do this first)

The mobile app can't run its own server — it needs to talk to a backend that's live on the public internet.

1. Take the `backend/` folder and deploy it to **Render**, **Railway**, or **Replit Deployments** (any of these work — Render's free tier is a reasonable starting point).
2. Set the `ANTHROPIC_API_KEY` environment variable / secret on whichever platform you use.
3. Once deployed, you'll get a public URL like `https://larder-backend.onrender.com`.
4. Open `mobile-app/www/index.html`, find:
   ```js
   const APP_CONFIG = {
     API_BASE_URL: "https://YOUR-DEPLOYED-BACKEND.example.com"
   };
   ```
   and replace it with your real deployed URL.

## Step 2 — Generate the app icon PNGs

I built the master icon as an SVG (`store-assets/icon-master.svg`) — this sandbox doesn't have an SVG-to-PNG renderer installed, so you'll need to convert it yourself (takes 2 minutes):

- Easiest: open [cloudconvert.com/svg-to-png](https://cloudconvert.com/svg-to-png), upload `icon-master.svg`, export at **1024×1024**.
- Then use an icon generator like [appicon.co](https://appicon.co) — upload the 1024×1024 PNG and it outputs every size Xcode needs, ready to drag into your asset catalog.

## Step 3 — Turn the web app into a real iOS app (Capacitor)

You'll need: a Mac, Node.js installed, and Xcode (free from the Mac App Store).

```bash
cd mobile-app
npm install
npx cap add ios
npx cap add android   # optional, if you also want Google Play later
npx cap sync
npx cap open ios
```

That last command opens the project in Xcode. From there:

1. In Xcode, select your Team under **Signing & Capabilities** (requires your Apple Developer account).
2. Drag your generated icon set into `Assets.xcassets` → `AppIcon`.
3. Open `ios/App/App/Info.plist` and add these two keys (required — this is what shows the permission prompt when the app asks to use the camera):
   - `NSCameraUsageDescription` → "Larder uses your camera to identify ingredients in your fridge or pantry."
   - `NSPhotoLibraryUsageDescription` → "Larder uses your photo library to identify ingredients you already have."
4. Pick a real device or simulator and hit **Run** to test it end to end — take a photo, confirm ingredients get recognized and recipes show up.

## Step 4 — Set up App Store Connect

1. Enroll in the [Apple Developer Program](https://developer.apple.com/programs/) ($99/year) if you haven't.
2. In [App Store Connect](https://appstoreconnect.apple.com), create a new app: bundle ID `com.larderapp.mobile` (matches `capacitor.config.json` — change both if you want a different ID).
3. Fill in the listing using `store-assets/app-store-listing.md` — name, subtitle, description, and keywords are all written and ready to paste in.
4. Set pricing: **Free**. Since monetization is affiliate-based (already built in — see "Missing ingredients" buy links), select Free under Pricing and Availability in App Store Connect. No in-app purchase code is needed for this model either.
5. Privacy Policy URL: I've already published one for you here: **[Larder Privacy Policy](https://claude.ai/artifact/Fy6qyhZ7CBxiHPmfYsQH5C)** — before you go live, fill in the bracketed placeholders in `store-assets/privacy-policy.html` (your name, contact email, actual data retention answer) and republish it, or host it wherever you prefer.
6. Support URL: point this at any page you control — even a simple contact page works.
7. Add screenshots: run the app in Xcode's simulator at each required screen size and capture screenshots (⌘S in Simulator).

## Step 5 — Archive and submit

In Xcode: **Product → Archive**, then use the Organizer window's **Distribute App** flow to upload to App Store Connect. Once it appears there, submit for review.

## One honest heads-up on Apple review

Apple's App Store Review Guideline 4.2 rejects apps that feel like "a repackaged website" with no native functionality. This build already avoids that by using the device's real native camera (via the Capacitor Camera plugin) instead of just a web file picker — that's a genuine native capability, not just a wrapped webpage. Still, expect Apple's first review pass to sometimes ask for more polish or native touches (haptics, sharing, offline behavior) — this is common for first submissions and not a sign anything here is broken.

## What's still deliberately out of scope for v1

- No accounts, no saved recipe history, no meal planning — matches the original MVP scope
- Android build is scaffolded (`npx cap add android`) but not walked through step-by-step here — ask if you want that too
- Recipe database is still the same 15 hardcoded recipes — worth expanding via Spoonacular/Edamam once you have real users
