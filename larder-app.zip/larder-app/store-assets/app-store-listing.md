# Larder — App Store Listing

## App name (30 char max)
Larder: Cook What You Have

## Subtitle (30 char max)
Snap your fridge, find dinner

## Promotional text (170 char max, editable anytime without review)
No more staring into the fridge wondering what to make. Snap a photo, and Larder shows you every recipe you can actually cook right now.

## Description

Stop planning meals around recipes you don't have the ingredients for.

Larder flips the usual recipe app around: instead of picking a dish and then checking what's missing, you start with what's actually in your kitchen. Snap a photo of your fridge or pantry, and Larder identifies what's there and shows you every recipe you can make right now — sorted by how close you are to "ready to cook."

HOW IT WORKS
• Take a photo of your fridge, pantry, or countertop
• Larder identifies the ingredients automatically
• Instantly see recipes ranked by what you have vs. what's missing
• Missing just a couple things? One tap to order them
• Tap any ingredient manually if you'd rather not use the camera

WHY LARDER
• Built for real kitchens — not aspirational grocery hauls
• See "ready now" recipes first, so dinner decisions take seconds
• Clear step-by-step instructions for every recipe
• No account required, no clutter, no ads

Whether you're trying to use up produce before it turns, avoid a grocery run, or just don't know what to make tonight — Larder starts from what's already yours.

## Keywords (100 char max, comma separated)
recipes,fridge,pantry,meal,cooking,leftovers,what to cook,groceries,ingredients,dinner ideas

## Category
Primary: Food & Drink
Secondary: Lifestyle

## Age rating
4+ (no objectionable content)

## Price tier
Free download. Monetization comes from affiliate links (Amazon + Instacart) already built into the app — see "Missing ingredients" section, `AFFILIATE_CONFIG` in `mobile-app/www/index.html`. Set this to Free in App Store Connect under Pricing and Availability.

## Support URL
(Required — a simple page or even a GitHub repo README works. Must be a real, reachable URL before submission.)

## Privacy Policy URL
(Required — see privacy-policy.html in this folder. Host it somewhere public before submitting; App Store Connect will reject the submission without a working link here.)

## What to prepare before submitting
- [ ] Apple Developer Program enrollment ($99/year) at developer.apple.com
- [ ] App icon PNGs generated from icon-master.svg (see README)
- [ ] 3–10 screenshots per required device size (Xcode Simulator can generate these)
- [ ] Support URL live
- [ ] Privacy Policy URL live
- [ ] Backend deployed to a public URL (see backend/README-deploy.md)
